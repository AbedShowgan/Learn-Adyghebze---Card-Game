package com.example.circassianwords_cardgame;

import org.junit.Test;

import static org.junit.Assert.*;

import java.util.HashMap;


/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    HashMap<Integer, Integer> combos = new HashMap<Integer, Integer>();
 //   private static boolean testPassed = true;
   //private static int testNum = 0;
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }


    @Test
    public void map_Test() {
//        combos.put(image11,image31);
//        combos.put(image12,image32);
//        combos.put(image13,image33);
//        combos.put(image21,image41);
//        combos.put(image22,image42);
//        combos.put(image23,image43);


    }

//
//    public static void main(String[] args) {
//        addition_isCorrect();
//        if (testPassed) {
//            System.out.println("All " + testNum + " tests passed!");
//        }
//    }


}