//package com.example.circassianwords_cardgame;
//
//import org.junit.Test;
//
//import java.io.FileNotFoundException;
//import java.util.ArrayList;
//
//public class testParser {
//
//
//    private static boolean testPassed = true;
//    private static int testNum = 0;
//
//    /**
//     * This entry function will test all classes created in this assignment.
//     * @param args command line arguments
//     */
//    public static void main(String[] args) throws FileNotFoundException {
//
//        /* TODO - write a function for each class separately */
//        // Each function here should test a different class. you should test here every class you created.
//        testEnglishList();
//
//
//        // etc....
//
//        // Notifying the user that the code have passed all tests.
//        if (testPassed) {
//            System.out.println("All " + testNum + " tests passed!");
//        }
//    }
//
//    /**
//     * This utility function will count the number of times it was invoked.
//     * In addition, if a test fails the function will print the error message.
//     * @param exp The actual test condition
//     * @param msg An error message, will be printed to the screen in case the test fails.
//     */
//    @Test
//    private static void test(boolean exp, String msg) {
//        testNum++;
//
//        if (!exp) {
//            testPassed = false;
//            System.out.println("Test " + testNum + " failed: "  + msg);
//        }
//    }
//
//    @Test
//    private static void testEnglishList() throws FileNotFoundException {
//        Parser myParser = new Parser("C:\\Users\\user\\Desktop\\Abed_Projects\\Circassian - Learn with Cards-Resources\\EnglishToAdyghe_Demo_first100");
//        ArrayList<String> english = myParser.getEnglish();
//        for (String s: english){
//            System.out.println(s + " \n");
//        }
//
//    }
//
//}
