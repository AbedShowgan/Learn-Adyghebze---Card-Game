package com.example.circassianwords_cardgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Main6x6Words extends MainActivity66Animals {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6x6_words);
    }
}