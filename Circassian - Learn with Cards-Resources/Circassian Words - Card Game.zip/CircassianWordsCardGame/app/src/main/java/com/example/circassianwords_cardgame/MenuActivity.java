package com.example.circassianwords_cardgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;


public class MenuActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Button btnPlay;
    Button btnDictionary;
    Button btnSettings;
    Button btnExit;

    String[] languages = { "ENG","ADYGHE" };
    Switch soundSwitch;

    //ENG, ADY
    RadioGroup langGroup;
    // horizontal//vertical
    RadioGroup alignmentGroup;
    //ENG-ADY
    RadioGroup translationGroup;

    RadioButton verticalBtn;
    RadioButton horizontalBtn;

    Spinner languageSpinner;
    RadioButton engLangButton;
    RadioButton adyLangButton;
    RadioButton E_A_modeButton;
    RadioButton I_A_modeButton;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_menu);

             btnPlay = findViewById(R.id.btnPlay);
             btnDictionary = findViewById(R.id.btnDictionary);
             btnSettings = findViewById(R.id.btnSettings);
             btnExit = findViewById(R.id.btnExitFromApp);

            languageSpinner = findViewById(R.id.languageSpinner);
            languageSpinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);

            // Create the instance of ArrayAdapter
            // having the list of courses
            ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item, languages);

            // set simple layout resource file
            // for each item of spinner
            ad.setDropDownViewResource(
                    android.R.layout
                            .simple_spinner_dropdown_item);

            // Set the ArrayAdapter (ad) data on the
            // Spinner which binds data to spinner
            languageSpinner.setAdapter(ad);
            // Performing action when ItemSelected
            // from spinner, Overriding onItemSelected method






    soundSwitch =  findViewById(R.id.soundSwitch);

            //ENG, ADY
             langGroup = findViewById(R.id.langRadioGroup);
            // horizontal//vertical
             alignmentGroup = findViewById(R.id.orientationRadioGroup);
            //ENG-ADY
             translationGroup = findViewById(R.id.translationRadioGroup);

             verticalBtn =  findViewById(R.id.verticalRadioButton);
             horizontalBtn =  findViewById(R.id.horizontalRadioButton);


             engLangButton =  findViewById(R.id.engRadioButton);
             adyLangButton =  findViewById(R.id.adyRadioButton);
             E_A_modeButton =  findViewById(R.id.eng_ady_RadioButton);
             I_A_modeButton =  findViewById(R.id.img_ady_RadioButton);


            btnPlay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Get Values from Settings, and Launch According Mode
                    // get selected radio button from language group
                    int selectedLang = langGroup.getCheckedRadioButtonId();
                    int selectedTranslation= translationGroup.getCheckedRadioButtonId();
                    boolean soundBool= soundSwitch.isChecked();
                    // find the radiobutton by returned id
                    RadioButton selectedLangButton = (RadioButton) findViewById(selectedLang);
                    RadioButton selectedTranslationButton = (RadioButton) findViewById(selectedTranslation);
                    //Choose English or Adyghe Language for APP
                    if(selectedLangButton.equals(engLangButton)){

                    }
                    else if((selectedLangButton.equals(adyLangButton))){
                        //Implement ADY interface
                    }
                    //Sound Portion
                    if(soundBool){
                        //sound on
                    }
                    else{
                     //no sound
                    }

                    //English-Adyghe Translation
                    if(selectedTranslationButton.equals(E_A_modeButton)){
                        // Start the main game activity
                        Intent intent = new Intent(MenuActivity.this, Main6x6Words.class);

                        startActivity(intent);
                    }

                    //Image-Adyghe Translation
                    else if((selectedLangButton.equals(I_A_modeButton))){
                        // Start the main game activity
                        Intent intent = new Intent(MenuActivity.this, MainActivity66Animals.class);

                        startActivity(intent);
                    }

                }
            });

            btnDictionary.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Start the main game activity
                    Intent intent = new Intent(MenuActivity.this, DictionaryView.class);
                    startActivity(intent);
                }
            });

            btnSettings.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Exit the app when the "Exit" button is clicked
                    Intent intent = new Intent(MenuActivity.this, settingsActivity.class);
                    startActivity(intent);
                }
            });
            btnExit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Exit the app when the "Exit" button is clicked
                    finish();
                }
            });
        }


    @Override
    public void onItemSelected(AdapterView<?> arg0,
                               View arg1,
                               int position,
                               long id)
    {

        // make toastof name of course
        // which is selected in spinner
        Toast.makeText(getApplicationContext(),
                        languages[position],
                        Toast.LENGTH_LONG)
                .show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


}

