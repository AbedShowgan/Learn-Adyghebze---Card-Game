package com.example.circassianwords_cardgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

public class settingsActivity extends AppCompatActivity {



    Button backMenuBtn;
    Button resetBtn;


    Switch soundSwitch;

    //ENG, ADY
    RadioGroup langGroup;
    // horizontal//vertical
    RadioGroup alignmentGroup;
    //ENG-ADY
    RadioGroup translationGroup;

    RadioButton verticalBtn;
    RadioButton horizontalBtn;


    RadioButton engLangButton;
    RadioButton adyLangButton;
    RadioButton E_A_modeButton;
    RadioButton I_A_modeButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
         backMenuBtn = findViewById(R.id.backButton);
         resetBtn = findViewById(R.id.resetButton);

         soundSwitch =  findViewById(R.id.soundSwitch);

        //ENG, ADY
         langGroup = findViewById(R.id.translationRadioGroup);
       // horizontal//vertical
         alignmentGroup = findViewById(R.id.orientationRadioGroup);
        //ENG-ADY
         translationGroup = findViewById(R.id.translationRadioGroup);

         verticalBtn =  findViewById(R.id.verticalRadioButton);
         horizontalBtn =  findViewById(R.id.horizontalRadioButton);


         engLangButton =  findViewById(R.id.engRadioButton);
         adyLangButton =  findViewById(R.id.adyRadioButton);
         E_A_modeButton =  findViewById(R.id.eng_ady_RadioButton);
         I_A_modeButton =  findViewById(R.id.img_ady_RadioButton);
        backMenuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Exit the app when the "Exit" button is clicked
                //Turn off Sound
                soundSwitch.setChecked(false);
                //Set Mode into "Vertical"
                verticalBtn.toggle();
                //Set language of App
                engLangButton.toggle();
                //Set Game Mode to Eng-Adyghe
                E_A_modeButton.toggle();
                Intent intent = new Intent(settingsActivity.this, MenuActivity.class);
                startActivity(intent);
            }
        });

        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Turn off Sound
                soundSwitch.setChecked(false);
                //Set Mode into "Vertical"
                verticalBtn.toggle();
                //Set language of App
                engLangButton.toggle();
                //Set Game Mode to Eng-Adyghe
                E_A_modeButton.toggle();
            }
        });
    }


}